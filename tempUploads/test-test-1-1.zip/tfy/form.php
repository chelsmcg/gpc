<!DOCTYPE <html>
	<html>
		<head>
			<title>Thoughtful For You - Form</title>
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width,initial-scale=1.0">
			<link rel="stylesheet" type="text/css" href="css/style.css">
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>

			<script type="text/javascript">
			$(document).ready(function(){

				$(".nextBtn").on("click", function() {
				    var nextPgId= $(this).attr("nextPgId");
				    var thisPgId= $(this).attr("thisPgId");
				    $("#" + thisPgId).hide();
				    $("#" + nextPgId).fadeIn();
				});

				$(".backBtn").on("click", function() {
				    var prevPgId= $(this).attr("prevPgId");
				    var thisPgId= $(this).attr("thisPgId");
				    $("#" + thisPgId).hide();
				    $("#" + prevPgId).fadeIn();
				});

				$('#login-form input[type="text"]').attr('style', '-webkit-box-shadow: inset 0 0 0 1000px #e5e5e5 !important');

    			$('#login-form input[type="password"]').attr('style', '-webkit-box-shadow: inset 0 0 0 1000px #e5e5e5 !important');

			});
		</script>
		</head>
		<body>
			<header>
				<img src="img/logo.png" class="logo"/>
			</header>

			<div class="container">
				<h1>CREATE REMINDER</h1>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
				Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
			
				<div class="formContainer" id="register-page1">
					<div class="formHeader">
						<p class="step">STEP 1.</p>
						<p class="instructions">Please Enter Person's Details</p>
					</div>
					<div class="progressBar width-85"></div>
					<div class="iconContainer">
						<span class="formStepIcon selected"></span>
						<span class="formStepIcon">r</span>
						<span class="formStepIcon"><img src="img/giftIcon.png"/></span>
						<span class="formStepIcon"></span>
					</div>
					<div class="formBody">
						<form id="register-form" action="" method="post" class="form">
							<div class="columnOne">
								<label>First Name:</label>
								<input name="pfName" type="text"></input>
								<label>Last Name:</label>
								<input name="plName" type="text"></input>
								<label>Suburb:</label>
								<input name="pSuburb" type="tel"></input>
							</div>
							<div class="columnTwo">
								<label>Relationship:</label>
								<input name="pfRelationship" type="text"></input>
								<label>Gender:</label>
								<span class="checkboxText">Male:</span><input name="pGender" id="r1" type="radio" class="checkbox"></input>
								<span class="checkboxText">Female:</span><input name="pGender" id="r2" type="radio" class="checkbox"></input>
								<div class="nextBtn" nextPgId="register-page2" thisPgId="register-page1">NEXT</div>
							</div>
						</form>
					</div>
				</div>

				<div class="formContainer displayNone" id="register-page2">
					<div class="formHeader">
						<p class="step">STEP 2.</p>
						<p class="instructions">Please Enter Reminder Dates</p>
					</div>
					<div class="progressBar width-492"></div>
					<div class="iconContainer">
						<span class="formStepIcon selected"></span>
						<span class="formStepIcon">r</span>
						<span class="formStepIcon"><img src="img/giftIcon.png"/></span>
						<span class="formStepIcon"></span>
					</div>
					<div class="formBody">
						<div class="columnOne">
							<form id="register-form" action="" method="post" class="form">
								<label>Date of Birth:</label>
								<select name="pDay" class="day">
								  <option value="00">Day</option>
								  <option value="01">1</option>
								  <option value="02">2</option>
								  <option value="03">3</option>
								  <option value="04">4</option>
								  <option value="05">5</option>
								  <option value="06">6</option>
								  <option value="07">7</option>
								  <option value="08">8</option>
								  <option value="09">9</option>
								  <option value="10">10</option>
								  <option value="11">11</option>
								  <option value="12">12</option>
								  <option value="13">13</option>
								  <option value="14">14</option>
								  <option value="15">15</option>
								  <option value="16">16</option>
								  <option value="17">17</option>
								  <option value="18">18</option>
								  <option value="19">19</option>
								  <option value="20">20</option>
								  <option value="21">21</option>
								  <option value="22">22</option>
								  <option value="23">23</option>
								  <option value="24">24</option>
								  <option value="25">25</option>
								  <option value="26">26</option>
								  <option value="27">27</option>
								  <option value="28">28</option>
								  <option value="29">29</option>
								  <option value="30">30</option>
								  <option value="31">31</option>
								</select>
								<select name="pMonth" class="month">
								  <option value="00">Month</option>
								  <option value="01">January</option>
								  <option value="02">February</option>
								  <option value="03">March</option>
								  <option value="04">April</option>
								  <option value="05">May</option>
								  <option value="06">June</option>
								  <option value="07">July</option>
								  <option value="08">August</option>
								  <option value="09">September</option>
								  <option value="10">October</option>
								  <option value="11">November</option>
								  <option value="12">December</option>
								</select>
								<input name="pYear" type="text" class="year" placeholder="Year"></input>
								<label>Anniversary:</label>
								<select name="pADay" class="day">
								  <option value="00">Day</option>
								  <option value="01">1</option>
								  <option value="02">2</option>
								  <option value="03">3</option>
								  <option value="04">4</option>
								  <option value="05">5</option>
								  <option value="06">6</option>
								  <option value="07">7</option>
								  <option value="08">8</option>
								  <option value="09">9</option>
								  <option value="10">10</option>
								  <option value="11">11</option>
								  <option value="12">12</option>
								  <option value="13">13</option>
								  <option value="14">14</option>
								  <option value="15">15</option>
								  <option value="16">16</option>
								  <option value="17">17</option>
								  <option value="18">18</option>
								  <option value="19">19</option>
								  <option value="20">20</option>
								  <option value="21">21</option>
								  <option value="22">22</option>
								  <option value="23">23</option>
								  <option value="24">24</option>
								  <option value="25">25</option>
								  <option value="26">26</option>
								  <option value="27">27</option>
								  <option value="28">28</option>
								  <option value="29">29</option>
								  <option value="30">30</option>
								  <option value="31">31</option>
								</select>
								<select name="pAMonth" class="month">
								  <option value="00">Month</option>
								  <option value="01">January</option>
								  <option value="02">February</option>
								  <option value="03">March</option>
								  <option value="04">April</option>
								  <option value="05">May</option>
								  <option value="06">June</option>
								  <option value="07">July</option>
								  <option value="08">August</option>
								  <option value="09">September</option>
								  <option value="10">October</option>
								  <option value="11">November</option>
								  <option value="12">December</option>
								</select>
								<input name="pAYear" type="text" class="year" placeholder="Year"></input>
								<label>Significant Date One:</label>
								<select name="pSigDay1" class="day">
								  <option value="00">Day</option>
								  <option value="01">1</option>
								  <option value="02">2</option>
								  <option value="03">3</option>
								  <option value="04">4</option>
								  <option value="05">5</option>
								  <option value="06">6</option>
								  <option value="07">7</option>
								  <option value="08">8</option>
								  <option value="09">9</option>
								  <option value="10">10</option>
								  <option value="11">11</option>
								  <option value="12">12</option>
								  <option value="13">13</option>
								  <option value="14">14</option>
								  <option value="15">15</option>
								  <option value="16">16</option>
								  <option value="17">17</option>
								  <option value="18">18</option>
								  <option value="19">19</option>
								  <option value="20">20</option>
								  <option value="21">21</option>
								  <option value="22">22</option>
								  <option value="23">23</option>
								  <option value="24">24</option>
								  <option value="25">25</option>
								  <option value="26">26</option>
								  <option value="27">27</option>
								  <option value="28">28</option>
								  <option value="29">29</option>
								  <option value="30">30</option>
								  <option value="31">31</option>
								</select>
								<select name="pSigMonth1" class="month">
								  <option value="00">Month</option>
								  <option value="01">January</option>
								  <option value="02">February</option>
								  <option value="03">March</option>
								  <option value="04">April</option>
								  <option value="05">May</option>
								  <option value="06">June</option>
								  <option value="07">July</option>
								  <option value="08">August</option>
								  <option value="09">September</option>
								  <option value="10">October</option>
								  <option value="11">November</option>
								  <option value="12">December</option>
								</select>
								<input name="pSigYear1" type="text" class="year" placeholder="Year"></input>
						</div>
						<div class="columnTwo">
								<label>Significate Date Two:</label>
								<select name="pSigDay2" class="day">
								  <option value="00">Day</option>
								  <option value="01">1</option>
								  <option value="02">2</option>
								  <option value="03">3</option>
								  <option value="04">4</option>
								  <option value="05">5</option>
								  <option value="06">6</option>
								  <option value="07">7</option>
								  <option value="08">8</option>
								  <option value="09">9</option>
								  <option value="10">10</option>
								  <option value="11">11</option>
								  <option value="12">12</option>
								  <option value="13">13</option>
								  <option value="14">14</option>
								  <option value="15">15</option>
								  <option value="16">16</option>
								  <option value="17">17</option>
								  <option value="18">18</option>
								  <option value="19">19</option>
								  <option value="20">20</option>
								  <option value="21">21</option>
								  <option value="22">22</option>
								  <option value="23">23</option>
								  <option value="24">24</option>
								  <option value="25">25</option>
								  <option value="26">26</option>
								  <option value="27">27</option>
								  <option value="28">28</option>
								  <option value="29">29</option>
								  <option value="30">30</option>
								  <option value="31">31</option>
								</select>
								<select name="pSigMonth2" class="month">
								  <option value="00">Month</option>
								  <option value="01">January</option>
								  <option value="02">February</option>
								  <option value="03">March</option>
								  <option value="04">April</option>
								  <option value="05">May</option>
								  <option value="06">June</option>
								  <option value="07">July</option>
								  <option value="08">August</option>
								  <option value="09">September</option>
								  <option value="10">October</option>
								  <option value="11">November</option>
								  <option value="12">December</option>
								</select>
								<input name="pSigYear2" type="text" class="year" placeholder="Year"></input>
								<label>Significate Date Three:</label>
								<select name="pSigDay3" class="day">
								  <option value="00">Day</option>
								  <option value="01">1</option>
								  <option value="02">2</option>
								  <option value="03">3</option>
								  <option value="04">4</option>
								  <option value="05">5</option>
								  <option value="06">6</option>
								  <option value="07">7</option>
								  <option value="08">8</option>
								  <option value="09">9</option>
								  <option value="10">10</option>
								  <option value="11">11</option>
								  <option value="12">12</option>
								  <option value="13">13</option>
								  <option value="14">14</option>
								  <option value="15">15</option>
								  <option value="16">16</option>
								  <option value="17">17</option>
								  <option value="18">18</option>
								  <option value="19">19</option>
								  <option value="20">20</option>
								  <option value="21">21</option>
								  <option value="22">22</option>
								  <option value="23">23</option>
								  <option value="24">24</option>
								  <option value="25">25</option>
								  <option value="26">26</option>
								  <option value="27">27</option>
								  <option value="28">28</option>
								  <option value="29">29</option>
								  <option value="30">30</option>
								  <option value="31">31</option>
								</select>
								<select name="pSigMonth3" class="month">
								  <option value="00">Month</option>
								  <option value="01">January</option>
								  <option value="02">February</option>
								  <option value="03">March</option>
								  <option value="04">April</option>
								  <option value="05">May</option>
								  <option value="06">June</option>
								  <option value="07">July</option>
								  <option value="08">August</option>
								  <option value="09">September</option>
								  <option value="10">October</option>
								  <option value="11">November</option>
								  <option value="12">December</option>
								</select>
								<input name="pSigYear3" type="text" class="year" placeholder="Year"></input>
						</div>
						<div class="buttonContainer">
							<div class="backBtn margin-top-213" prevPgId="register-page1" thisPgId="register-page2">BACK</div>
							<div class="nextBtn margin-top-213" nextPgId="register-page3" thisPgId="register-page2">NEXT</div>
						</div>
						</form>
					</div>
				</div>

				<div class="formContainer displayNone" id="register-page3">
					<div class="formHeader">
						<p class="step">STEP 3.</p>
						<p class="instructions">Registration Complete</p>
					</div>
					<div class="progressBar width-960"></div>
					<div class="iconContainer">
						<span class="stepIcon selected"></span>
						<span class="stepIcon selected">6</span>
						<span class="stepIcon selected"></span>
					</div>
					<div class="formBody">
						<div class="columnOne">
							<p class="successText">Registration Successful!</p>
							<p class="successSubText">A confirmation email will be sent to "email@example.com.au"</p>
							<div class="backBtn margin-top-324" prevPgId="register-page2" thisPgId="register-page3">DONE</div>
						</div>
						<div class="columnTwo">
							<form id="login-form" action="" method="post" class="form">
								<label>Username <span class="italic">(Phone Number):</span></label>
								<input type="text" name="cPhone"></input>
								<label>Password:</label>
								<input type="password" name="password"></input>
								<div class="nextBtn margin-top-295">LOGIN</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			
		</body>
	</html>